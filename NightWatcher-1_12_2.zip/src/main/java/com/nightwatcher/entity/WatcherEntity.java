package com.nightwatcher.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * O Observador: persegue o jogador, mas CONGELA enquanto alguem olha para ele.
 * Perto dele a tela do jogador fica tonta (nausea). Quando ele acerta, deixa o alvo cego por 3 segundos.
 */
public class WatcherEntity extends EntityMob {
	// Quanto tempo ele fica no mundo antes de sumir (4 minutos).
	private static final int LIFETIME_TICKS = 20 * 60 * 4;
	// Distancia (em blocos) em que ele deixa os jogadores tontos.
	private static final double NAUSEA_RANGE = 16.0D;

	private int lifeTicks = 0;
	private boolean wasWatched = false;
	private int stingerCooldown = 0;

	public WatcherEntity(World world) {
		super(world);
		this.setSize(0.6F, 2.6F);
	}

	@Override
	protected void initEntityAI() {
		// Prioridade 0 = mais importante: se estao olhando, ele para de tudo.
		this.tasks.addTask(0, new AIFreezeWhenWatched(this));
		this.tasks.addTask(1, new EntityAIAttackMelee(this, 1.0D, false));
		this.tasks.addTask(2, new EntityAIWanderAvoidWater(this, 0.8D));
		this.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 16.0F));
		this.tasks.addTask(4, new EntityAILookIdle(this));
		// false = ele te persegue mesmo sem te ver
		this.targetTasks.addTask(1, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class, false));
	}

	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0D);
		this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.36D);
		this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(6.0D);
		this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(48.0D);
	}

	/** True se algum jogador esta olhando na direcao dele (com linha de visao). */
	public boolean isBeingWatched() {
		for (EntityPlayer player : this.world.playerEntities) {
			if (player.isSpectator()) {
				continue;
			}
			if (this.getDistance(player) > 64.0F) {
				continue;
			}
			Vec3d look = player.getLook(1.0F).normalize();
			Vec3d toWatcher = new Vec3d(
					this.posX - player.posX,
					(this.getEntityBoundingBox().minY + this.getEyeHeight()) - (player.posY + player.getEyeHeight()),
					this.posZ - player.posZ
			);
			double dist = toWatcher.lengthVector();
			if (dist < 0.001D) {
				return true;
			}
			toWatcher = toWatcher.normalize();
			// 0.7 = ele precisa estar mais ou menos no campo de visao do jogador
			if (look.dotProduct(toWatcher) > 0.7D && player.canEntityBeSeen(this)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void onUpdate() {
		super.onUpdate();
		if (this.world.isRemote) {
			return;
		}

		this.lifeTicks++;
		if (this.lifeTicks > LIFETIME_TICKS) {
			this.setDead();
			return;
		}

		// Grito quando alguem o ve (com intervalo para nao repetir toda hora)
		boolean watched = this.isBeingWatched();
		if (this.stingerCooldown > 0) {
			this.stingerCooldown--;
		}
		if (watched && !this.wasWatched && this.stingerCooldown == 0) {
			this.playSound(SoundEvents.ENTITY_ENDERMEN_STARE, 1.5F, 0.5F);
			this.stingerCooldown = 200;
		}
		this.wasWatched = watched;

		// Deixa a tela tonta de quem esta perto
		if (this.ticksExisted % 20 == 0) {
			for (EntityPlayer player : this.world.playerEntities) {
				if (!player.isSpectator() && this.getDistanceSq(player) < NAUSEA_RANGE * NAUSEA_RANGE) {
					player.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 120, 0, false, false));
				}
			}
		}
	}

	@Override
	public boolean attackEntityAsMob(Entity target) {
		boolean hit = super.attackEntityAsMob(target);
		if (hit && target instanceof EntityLivingBase) {
			((EntityLivingBase) target).addPotionEffect(new PotionEffect(MobEffects.BLINDNESS, 60, 0, false, false));
		}
		return hit;
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return SoundEvents.ENTITY_ENDERMEN_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.ENTITY_ENDERMEN_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.ENTITY_ENDERMEN_DEATH;
	}

	/** Tarefa de IA que segura o monstro parado enquanto estao olhando para ele. */
	private static class AIFreezeWhenWatched extends EntityAIBase {
		private final WatcherEntity watcher;

		AIFreezeWhenWatched(WatcherEntity watcher) {
			this.watcher = watcher;
			this.setMutexBits(3); // bloqueia movimento (1) e olhar (2)
		}

		@Override
		public boolean shouldExecute() {
			return this.watcher.isBeingWatched();
		}

		@Override
		public boolean shouldContinueExecuting() {
			return this.watcher.isBeingWatched();
		}

		@Override
		public void startExecuting() {
			this.watcher.getNavigator().clearPath();
		}
	}
}
