package com.nightwatcher.item;

import com.nightwatcher.NightWatcher;
import com.nightwatcher.entity.WatcherEntity;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Ovo vermelho e preto: clique com o botao direito num bloco para invocar o Observador.
 */
public class ItemWatcherEgg extends Item {

	public ItemWatcherEgg() {
		this.setRegistryName(NightWatcher.MODID, "watcher_egg");
		this.setUnlocalizedName(NightWatcher.MODID + ".watcher_egg");
		this.setCreativeTab(CreativeTabs.MISC);
	}

	@Override
	public EnumActionResult onItemUse(EntityPlayer player, World world, BlockPos pos, EnumHand hand,
			EnumFacing facing, float hitX, float hitY, float hitZ) {
		if (world.isRemote) {
			return EnumActionResult.SUCCESS;
		}
		ItemStack stack = player.getHeldItem(hand);
		BlockPos spawnPos = pos.offset(facing);
		if (!player.canPlayerEdit(spawnPos, facing, stack)) {
			return EnumActionResult.FAIL;
		}

		WatcherEntity watcher = new WatcherEntity(world);
		watcher.setLocationAndAngles(spawnPos.getX() + 0.5D, spawnPos.getY(), spawnPos.getZ() + 0.5D,
				world.rand.nextFloat() * 360.0F, 0.0F);
		watcher.rotationYawHead = watcher.rotationYaw;
		watcher.renderYawOffset = watcher.rotationYaw;
		watcher.onInitialSpawn(world.getDifficultyForLocation(spawnPos), null);
		world.spawnEntity(watcher);

		if (!player.capabilities.isCreativeMode) {
			stack.shrink(1);
		}
		return EnumActionResult.SUCCESS;
	}
}
