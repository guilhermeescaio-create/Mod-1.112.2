package com.nightwatcher.client;

import com.nightwatcher.NightWatcher;
import com.nightwatcher.entity.WatcherEntity;

import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class WatcherRenderer extends RenderLiving<WatcherEntity> {
	private static final ResourceLocation TEXTURE = new ResourceLocation(NightWatcher.MODID, "textures/entity/watcher.png");

	public WatcherRenderer(RenderManager manager) {
		super(manager, new WatcherModel(), 0.4F);
	}

	@Override
	protected ResourceLocation getEntityTexture(WatcherEntity entity) {
		return TEXTURE;
	}
}
