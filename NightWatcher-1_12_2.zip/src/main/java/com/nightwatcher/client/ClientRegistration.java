package com.nightwatcher.client;

import com.nightwatcher.ModItems;
import com.nightwatcher.NightWatcher;
import com.nightwatcher.entity.WatcherEntity;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = NightWatcher.MODID, value = Side.CLIENT)
public class ClientRegistration {

	@SubscribeEvent
	public static void registerRenderers(ModelRegistryEvent event) {
		RenderingRegistry.registerEntityRenderingHandler(WatcherEntity.class, WatcherRenderer::new);
		// Modelo do ovo vermelho e preto (assets/nightwatcher/models/item/watcher_egg.json)
		ModelLoader.setCustomModelResourceLocation(ModItems.WATCHER_EGG, 0,
				new ModelResourceLocation(ModItems.WATCHER_EGG.getRegistryName(), "inventory"));
	}
}
