package com.nightwatcher.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/** Modelo alto e magro: pernas 18 + corpo 16 + cabeca 8 = 42 pixels (~2,6 blocos). */
public class WatcherModel extends ModelBase {
	private final ModelRenderer head;
	private final ModelRenderer body;
	private final ModelRenderer leftArm;
	private final ModelRenderer rightArm;
	private final ModelRenderer leftLeg;
	private final ModelRenderer rightLeg;

	public WatcherModel() {
		this.textureWidth = 64;
		this.textureHeight = 64;

		// No modelo, Y maior = mais para baixo. O chao fica em y = 24.
		this.head = new ModelRenderer(this, 0, 0);
		this.head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8);
		this.head.setRotationPoint(0.0F, -10.0F, 0.0F);

		this.body = new ModelRenderer(this, 16, 16);
		this.body.addBox(-3.0F, -16.0F, -2.0F, 6, 16, 4);
		this.body.setRotationPoint(0.0F, 6.0F, 0.0F);

		this.leftArm = new ModelRenderer(this, 40, 16);
		this.leftArm.mirror = true;
		this.leftArm.addBox(-1.0F, 0.0F, -1.0F, 2, 20, 2);
		this.leftArm.setRotationPoint(5.0F, -8.0F, 0.0F);

		this.rightArm = new ModelRenderer(this, 40, 16);
		this.rightArm.addBox(-1.0F, 0.0F, -1.0F, 2, 20, 2);
		this.rightArm.setRotationPoint(-5.0F, -8.0F, 0.0F);

		this.leftLeg = new ModelRenderer(this, 0, 16);
		this.leftLeg.mirror = true;
		this.leftLeg.addBox(-1.5F, 0.0F, -1.5F, 3, 18, 3);
		this.leftLeg.setRotationPoint(1.5F, 6.0F, 0.0F);

		this.rightLeg = new ModelRenderer(this, 0, 16);
		this.rightLeg.addBox(-1.5F, 0.0F, -1.5F, 3, 18, 3);
		this.rightLeg.setRotationPoint(-1.5F, 6.0F, 0.0F);
	}

	@Override
	public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
		this.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);
		this.head.render(scale);
		this.body.render(scale);
		this.leftArm.render(scale);
		this.rightArm.render(scale);
		this.leftLeg.render(scale);
		this.rightLeg.render(scale);
	}

	@Override
	public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entity) {
		this.head.rotateAngleY = netHeadYaw * 0.017453292F;
		this.head.rotateAngleX = headPitch * 0.017453292F;

		this.leftLeg.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.2F * limbSwingAmount;
		this.rightLeg.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 1.2F * limbSwingAmount;

		// Bracos compridos pendurados, balancando de leve (bem creepy)
		float sway = MathHelper.sin(ageInTicks * 0.05F) * 0.04F;
		this.leftArm.rotateAngleX = -0.15F + MathHelper.cos(limbSwing * 0.6662F) * 0.5F * limbSwingAmount;
		this.rightArm.rotateAngleX = -0.15F + MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 0.5F * limbSwingAmount;
		this.leftArm.rotateAngleZ = -0.06F - sway;
		this.rightArm.rotateAngleZ = 0.06F + sway;
	}
}
