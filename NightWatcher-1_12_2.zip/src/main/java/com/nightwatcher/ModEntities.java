package com.nightwatcher;

import com.nightwatcher.entity.WatcherEntity;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;

@Mod.EventBusSubscriber(modid = NightWatcher.MODID)
public class ModEntities {

	@SubscribeEvent
	public static void registerEntities(RegistryEvent.Register<EntityEntry> event) {
		event.getRegistry().register(
				EntityEntryBuilder.create()
						.entity(WatcherEntity.class)
						.id(new ResourceLocation(NightWatcher.MODID, "watcher"), 0)
						.name(NightWatcher.MODID + ".watcher")
						.tracker(64, 3, true)
						.build()
		);
	}
}
