package com.nightwatcher;

import java.util.ArrayList;

import com.nightwatcher.entity.WatcherEntity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * Faz o Observador aparecer de noite, no escuro, perto de jogadores que estao ao ar livre.
 */
@Mod.EventBusSubscriber(modid = NightWatcher.MODID)
public class WatcherSpawner {
	// A cada quantos ticks verificamos (200 ticks = 10 segundos)
	private static final int CHECK_INTERVAL = 200;
	// 1 chance em N a cada verificacao. Aumente N para ele aparecer menos.
	private static final int CHANCE = 8;

	@SubscribeEvent
	public static void onWorldTick(TickEvent.WorldTickEvent event) {
		if (event.phase != TickEvent.Phase.END || event.side != Side.SERVER) {
			return;
		}
		World world = event.world;
		if (world.provider.getDimension() != 0) {
			return;
		}
		if (world.getTotalWorldTime() % CHECK_INTERVAL != 0) {
			return;
		}
		if (world.getDifficulty() == EnumDifficulty.PEACEFUL) {
			return;
		}
		for (EntityPlayer player : new ArrayList<EntityPlayer>(world.playerEntities)) {
			trySpawn(world, player);
		}
	}

	private static void trySpawn(World world, EntityPlayer player) {
		if (player.isSpectator()) {
			return;
		}
		if (!world.canSeeSky(player.getPosition())) {
			return;
		}
		if (world.rand.nextInt(CHANCE) != 0) {
			return;
		}
		// So um Observador por vez por perto
		if (!world.getEntitiesWithinAABB(WatcherEntity.class, player.getEntityBoundingBox().grow(96.0D)).isEmpty()) {
			return;
		}

		double angle = world.rand.nextDouble() * Math.PI * 2.0D;
		double distance = 22 + world.rand.nextInt(10);
		int x = MathHelper.floor(player.posX + Math.cos(angle) * distance);
		int z = MathHelper.floor(player.posZ + Math.sin(angle) * distance);
		if (!world.isBlockLoaded(new BlockPos(x, 64, z))) {
			return;
		}
		BlockPos pos = world.getHeight(new BlockPos(x, 0, z));
		if (world.getBlockState(pos.down()).getMaterial().isLiquid()) {
			return;
		}
		// So aparece no escuro (noite)
		if (world.getLightFromNeighbors(pos) > 7) {
			return;
		}

		WatcherEntity watcher = new WatcherEntity(world);
		watcher.setLocationAndAngles(x + 0.5D, pos.getY(), z + 0.5D, world.rand.nextFloat() * 360.0F, 0.0F);
		world.spawnEntity(watcher);
	}
}
